/**
 * 后台接口文件
 */

const
			BackendApiHomepage = '/mock/main/main',							// 首页
			BackendApiSpecial = '/mock/butler-article/special',			// 专题精选
			BackendApiDiscovery = '/find-main',									// 发现 - 发现（达人推荐）
			BackendApiCategory = '/category-main/index',							// 商品分类
			BackendApiSubcategory = '/goods-main/list',			// 商品列表（商品分类二级，cat_id: 分类ID）
			BackendApiBrand = '/goods-brand/list',							// 品牌制造商列表
			BackendApiLike = '/mock/butler-article/like',						// 点赞接口
			BackendApiUnLike = '/butler-article/unlike',					// 取消点赞接口
			BackendApiCollectAdd = '/goods-favorite?a=add',			// 收藏
			BackendApiCollectDel = '/goods-favorite?a=del',			// 收藏
			BackendApiDasan = '/butler-article/reward',				// 文章打赏
			BackendApiDoyenList = '/mockwap/butler-doyen/list'				// 达人列表，doyen_type: 1-采购，2-编辑 3-达人
			;

export {
	BackendApiHomepage,
	BackendApiSpecial,
	BackendApiDiscovery,
	BackendApiCategory,
	BackendApiSubcategory,
	BackendApiBrand,
	BackendApiLike,
	BackendApiUnLike,
	BackendApiCollectAdd,
	BackendApiCollectDel,
	BackendApiDasan,
	BackendApiDoyenList,
};