
import { QqwReg } from '../../../../js/qqw_regex';
import { QqwUtil, Loading } from '../../../../js/qqw_ultilities';

let orderApi = {
	// 2-1. 后台接口
	listOrder: '/user-order/list?client=web',
	detailOrder: '/user-order/detail?client=web',
	trackOrder: '/user-order/track?client=web',
	customServiceType: '/user-order/getservice',
	customServiceApply: '/user-order/service',
	customServiceDetail: '/user-order/serviceDetail',
	// 2-2. 后台操作接口
	cancelOrder: '/user-order/cancel?client=web',
	delOrder: '/user-order/del?client=web',
	confirmReceipt: '/user-order/doget?client=web',
	// 3. 跳转链接
	paymentFormAction: '/payment-pay/paySubmit',
	gotoPayment: '/payment-pay/wechat?client=web&os=h5&order_sn=',
	gotoOrderDetail: '/mobile-user-order/detail?order_sn=',
	gotoOrderTrack: '/mobile-user-order/track?order_sn=',
	gotoOrderComment: '/mobile-user-rate/goods?order_sn=',
	gotoOrderRefund: '/mobile-user-refund/apply?order_sn=',
};

let loading = new Loading();

/**
 * [doBtnClick description]
 * @param  {[type]} target [description]
 * @return {[type]}        [description]
 */
function doBtnClick(btn_name, order_sn, cb) {
	// let iswechat = document.getElementById('U-isWechat').value;
	switch(btn_name){
	 	case 'btnCancel':
	 		// cancelOrder.init(order_sn);
	 		cancelOrder(order_sn, cb);
	 		break;
	 	case 'btnDelete':
			console.log('2. -----> btn_name = ' + btn_name + ', order_sn = ' + order_sn);
	 		// delOrder.init(order_sn);
	 		delOrder(order_sn);
	 		break;
	 	case 'btnPayment': //去付款按钮
	 		// payment.init(order_sn);
	 		gotoPayment(order_sn);
	 		break;
	 	case 'btnTrack':
	    location.href = orderApi.gotoOrderTrack + order_sn;
	    break;
	 	case 'btnComment':
	 		location.href = orderApi.gotoOrderComment + order_sn;
	    break;
	  case 'btnConfirmReceipt':
	  	confirmReceipt(order_sn);
      // configReceipt.init(order_sn);
      // break;
    case 'btnRefund':
    	location.href = orderApi.gotoOrderRefund + order_sn;
    	break;
	}
}

function cancelOrder(sn, cb) {
	layer.open({
  	type: 1,
  	skin: 'lorder-layer-cancel', //样式类名
  	closeBtn: 0, //不显示关闭按钮
  	shift: 2,
  	shadeClose: true, //开启遮罩关闭
  	content: ''
	});

	orderListCommonHandling(cb, 'post', sn, orderApi.cancelOrder);
}

function delOrder(sn) {
	orderListCommonHandling((data) => {
        // location.reload();		---->
  }, 'post', sn, orderApi.delOrder, true, '删除订单');
}

function confirmReceipt(sn) {
	orderListCommonHandling((data) => {
        // location.reload();		---->
  }, 'post', sn, orderApi.confirmReceipt, true, '确认收货');
}

function orderListCommonHandling(cb, ajaxMethod, sn, api, needConfirm=false, confirmStr='') {
	if ( QqwReg.valiatorReg.isEmpty(sn) ) {
		QqwUtil.msg("订单号错误");
		return ;
	}
	loading.show();
	if (needConfirm) {
		QqwUtil.confirm(confirmStr, () => {
	    QqwUtil.ajaxData(ajaxMethod, api, {order_sn: sn}, cb);
	  }, null);
	} else {
		QqwUtil.ajaxData(ajaxMethod, api, {order_sn: sn}, cb);
	}
}

function gotoPayment(sn) {

	let isWechat = parseInt($("#U-isWechat").val());
	let payId = isWechat ? 6 : 2;
	if (isWechat == 1){
		location.href = orderApi.gotoPayment + sn;
		return;
	}
	if (QqwReg.valiatorReg.isEmpty(sn)) {
		QqwUtil.msg("订单号错误");
		return ;
	}
	loading.show();
	submitForm(sn, payId);
	/*ajaxData('post', '/payment-pay/paySubmit?client=web', {order_sn: i.order_sn, pay_id: 2},
		function(data){
			location.href='/mobile-user-order/success?order_sn='+i.order_sn;
		})*/

}

function submitForm(sn, payId){
	let o = this;
	// 创建Form
	var form = $('<form></form>');
	// 设置属性
	form.attr('action', orderApi.paymentFormAction);
	form.attr('method', 'post');
	// form的target属性决定form在哪个页面提交  _self -> 当前页面 _blank -> 新页面
	form.attr('target', '_self');
	// 创建Input
	let pEl = $('<input type="text" name="pay_id" value="' + payId + '" />');
	let snEl = $('<input type="text" name="order_sn" value="' + sn + '" />');
	// pEl.attr('value', payId);
	// snEl.attr('value', sn);
	// 附加到Form
	form.append(pEl);
	form.append(snEl);
	// 提交表单
	form.submit();
}

export { orderApi, doBtnClick };