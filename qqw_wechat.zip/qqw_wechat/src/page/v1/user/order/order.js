import { QqwUtil, Loading } from '../../../js/qqw_ultilities';
import { QqwReg } from '../../../js/qqw_regex';
import { EventUtil } from '../../../js/qqw_eventutil';
import { PullPush } from '../../../js/qqw_pullpush';

// let tplRender = require('file!tmod?{"syntax": "native", "runtime": "template.js", "suffix": ".tpl"}!../../../tpl/user_order_list.tpl');

import tpl_userOrderList from '../../../tpl/user_order_list.tpl';
import tpl_userOrderDetail from '../../../tpl/user_order_detail.tpl';
import tpl_userOrderTrack from '../../../tpl/user_order_track.tpl';
import template from '../../../js/template-native-debug.js';

let orderUrl
		, tplRender
		, orderApi
		, orderStore
		, scrollHandler
		;

orderApi = {
	// 2-1. 后台接口
	listOrder: '/user-order/list?client=web',
	detailOrder: '/user-order/detail?client=web',
	trackOrder: '/user-order/track?client=web',
	// 2-2. 后台操作接口
	cancelOrder: '/user-order/cancel?client=web',
	delOrder: '/user-order/del?client=web',
	confirmReceipt: '/user-order/doget?client=web',
	// 3. 跳转链接
	gotoOrderDetail: '/mobile-user-order/detail?order_sn=',
	gotoOrderTrack: '/mobile-user-order/track?order_sn=',
	gotoOrderComment: '/mobile-user-rate/goods?order_sn=',
};

// 数据状态
orderStore = {
	p: 1,
	lastP: 1,
	ps: 48,			// 抓取48条
	each: 12,		// 每次渲染加载12条
	totalItemCount: 0,
	orderItemIdx: 0,		// 已加载条数，当数据只剩下12条未渲染时，预先抓取
	orderItemArr: [],		// 缓存已加载的数据
	type: 1,
	speed: 5,
	scrollSignDistance: 120,
	shouldPrefetch: false,
	flag: true,			// 还有更多数据？
	isLock: false,
	loading: new Loading(true)
};

// 监听滚动事件
scrollHandler = new PullPush(orderStore.scrollSignDistance, () => {
	if (!orderStore.flag) {			// 没有更多数据了
		scrollHandler.cancelOb();
		return ;
	}
	// 1. 是否需要预先抓取
	if (orderStore.orderItemIdx >= orderStore.ps) {
		orderStore.loading.show();
		setTimeout(function() {
			orderStore.loading.hide();
		}, 3000);		// 3s后消失，增强用户体验
	}
	if (orderStore.shouldPrefetch && orderStore.lastP !== orderStore.p) {		// 分页索引相等则表示先前的网络请求没有返回或失败
		let paramObj = { type: orderStore.type, p: orderStore.p, ps: orderStore.ps };
		orderStore.lastP = orderStore.p;
		fetchOrderList(paramObj, (data) => {
	  	renderOrder(data);
		});
	}
	// 2. 是否缓存的数据全都加载完毕
	if (orderStore.orderItemIdx >= orderStore.ps) {
		orderStore.orderItemIdx = 0;
		orderStore.totalItemCount = 0;
		orderStore.orderItemArr = [];
		return ;
	}
	// 3. 检测是否到达预先抓取的条件
	if ((orderStore.orderItemIdx + orderStore.each) >= orderStore.ps) {
		orderStore.shouldPrefetch = true;
	}
	// 4. 加载更多
	let curRenderItemArr = orderStore.orderItemArr.slice(orderStore.orderItemIdx, orderStore.orderItemIdx + orderStore.each);
	orderStore.orderItemIdx += orderStore.each;
	renderOrder(curRenderItemArr);
});

/**
 *
 * 流程
 *  1. 先发网络请求（4. 渲染 dom）
 *  2. 完成 dom 加载，显示loading
 *  3. 加载完处理移动端click hack
 *  - 注意 2~3 不可执行需要长时间计算的操作
 *
 * Author: Kevin(212499714@qq.com)
 */
QqwUtil.main(function*(){
	orderStore.type = User.Order.$data || '';

	let paramObj;
	if (User.Order.list) {
		orderUrl = orderApi.listOrder;
		paramObj = { type: orderStore.type, p: orderStore.p, ps: orderStore.ps };
		orderStore.lastP = orderStore.p;			// 防止网络失败情况下不断抓取更多数据
	} else if (User.Order.detail) {
		orderUrl = orderApi.detailOrder;
		paramObj = { order_sn: orderStore.type};
	} else if (User.Order.track) {
		orderUrl = orderApi.trackOrder;
		orderStore.type = QqwUtil.getSearchToJson()['order_sn'];
		paramObj = { order_sn: orderStore.type};
	}

	fetchOrderList(paramObj, (data) => {
	  renderOrder(data);
		User.Order.list && scrollHandler.ob();
	});

  yield EventUtil.domReady();
  console.log('白屏时间 = ' + (new Date().getTime() - window.startTime));

	orderStore.loading.show();
	FastClick.attach(document.body);			// 移动端点击事件 hack
	if (User.Order.list) {
		tplRender = template.compile(tpl_userOrderList);
  	bindOrderList();
	} else if (User.Order.detail) {
		tplRender = template.compile(tpl_userOrderDetail);
		bindOrderDetail();
	} else if (User.Order.track) {
		tplRender = template.compile(tpl_userOrderTrack);
	}
});

// ===========================================================
/**
 * 后台获取订单列表
 * @param  {[type]}   paramObj [接口方法参数]
 * @param  {Function} cb       [接口返回成功后的回调]
 */
function fetchOrderList(paramObj, cb) {
	orderStore.hasnotHide = true;
	QqwUtil.ajaxData('get', orderUrl, paramObj, (data) => {
		let startGetQqwOpDataTime = new Date().getTime();	// for 性能检测
		orderStore.totalItemCount += data.length;
		orderStore.flag = data.length < orderStore.ps ? false : true;
		orderStore.flag && ++orderStore.p;
		cb && cb(data);
		console.log('加载HTML到渲染后台数据花费毫秒数 = ' + (new Date().getTime() - window.startTime) +
			', 其中渲染后台数据花费 = ' + (new Date().getTime() - startGetQqwOpDataTime));
	});
}

function renderOrder(data) {
	orderStore.loading.hide();
	if (User.Order.list) {
		QqwUtil.renderTemplate.append('U-orderList', tplRender({list: data}) );
	} else if (User.Order.detail) {
		QqwUtil.renderTemplate.append('U-orderDetail', tplRender({data: data}) );
	} else if (User.Order.track) {
		QqwUtil.renderTemplate.append('U-orderTrackList', tplRender({list: data}));
	}
}

/**
 * 订单列表模板父结点绑定click事件
 * @return {[type]} [description]
 */
function bindOrderList() {
	EventUtil.addHandler(document.getElementById('U-orderList'), 'click', (event) => {
  	event = EventUtil.getEvent(event);
    let target = EventUtil.getTarget(event);
    if (target.nodeName === 'BUTTON') {
    	EventUtil.stopPropagation(event);
    	EventUtil.preventDefault(event);
    	doBtnClick(target.dataset.btn-name, target.datasetorder-sn);
    	return ;
    }
    if (target.className.indexOf('list') !== -1) {
    	location.href = orderApi.gotoOrderDetail + this.dataset.order_sn;
    }
  });
}

function bindOrderDetail() {
	EventUtil.addHandler(document.getElementById('U-orderDetail'), 'click', (event) => {
  	event = EventUtil.getEvent(event);
    let target = EventUtil.getTarget(event);
    if (target.nodeName === 'DD') {
    	EventUtil.stopPropagation(event);
    	EventUtil.preventDefault(event);
    	doBtnClick(target.dataset.btn, target.parentElement.dataset.order_sn);
    	return ;
    }
  });
}

/**
 * [doBtnClick description]
 * @param  {[type]} target [description]
 * @return {[type]}        [description]
 */
function doBtnClick(btn_name, order_sn) {
	// let iswechat = document.getElementById('U-isWechat').value;
	switch(btn_name){
	 	case 'btnCancel':
	 		// cancelOrder.init(order_sn);
	 		cancelOrder(order_sn);
	 		break;
	 	case 'btnDelete':
	 		// delOrder.init(order_sn);
	 		delOrder(order_sn);
	 		break;
	 	case 'btnPayment': //去付款按钮
	 		// payment.init(order_sn);
	 		break;
	 	case 'btnTrack':
	    location.href = orderApi.gotoOrderTrack + order_sn;
	    break;
	 	case 'btnComment':
	 		location.href = orderApi.gotoOrderComment + order_sn;
	    break;
	  case "btnConfirmReceipt" :
      // configReceipt.init(order_sn);
      // confirmReceipt(order_sn);
      // break;
	}
}

orderTrack = {
	    options:{
	        isLock:!1,
	        speed:5,
	    },
	    init:function() {
	        var i = this;
	        i.loading = new G.loading(),
	        i.bind();
	    },
	    bind:function() {
	        var i = this;
	        i.getTackList();
	    },
	    getTackList:function() {
	        var i = this;
	        ajaxData('get', '/user-order/track?client=web', 
	                {order_sn: G.getUrlParam('order_sn'),}, 
	                function(data){
	                	 i.orderTrackData(data);
	        });
	    },
	    orderTrackData: function(data){
	    	var i = this;
	        var json = {};
	        json.list = data;
	        
	     }
};


function cancelOrder(sn) {
	orderListCommonHandling((data) => {
        // location.reload();		---->
  }, 'post', sn, orderApi.cancelOrder);
}

function delOrder(sn) {
	orderListCommonHandling((data) => {
        // location.reload();		---->
  }, 'post', sn, orderApi.delOrder, true, '删除订单');
}

function confirmReceipt(sn) {
	orderListCommonHandling((data) => {
        // location.reload();		---->
  }, 'post', sn, orderApi.confirmReceipt, true, '确认收货');
}

function orderListCommonHandling(cb, ajaxMethod, sn, api, needConfirm=false, confirmStr='') {
	if ( QqwReg.valiatorReg.isEmpty(sn) ) {
		QqwUtil.msg("订单号错误");
		return ;
	}
	if (needConfirm) {
		QqwUtil.confirm(confirmStr, function() {
			orderStore.loading.show();
	    QqwUtil.ajaxData(ajaxMethod, api, {order_sn: sn}, cb);
	  });
	} else {
		orderStore.loading.show();
		QqwUtil.ajaxData(ajaxMethod, api, {order_sn: sn}, cb);
	}
}


var payment = {
		options:{
		   isLock:!1
		},	
		init:function(sn) {
		     var i = this;
		      i.loading = new Loading(),
		      i.order_sn = sn;
		     // console.log(sn);
		      i.doPayment();
		},
		valiatorOrderSn:function() {
		       var i = this;
		       return valiatorReg.isEmpty(i.order_sn) ? (QqwUtil.msg("订单号错误"), i.options.isLock = !1, !1) :!0;
		},
		doPayment:function(){
			var i = this;
			var payId = 2;  
			var isWechat = parseInt($("#U-isWechat").val());
			//alert(isWechat);return;
			payId = isWechat ? 6 : payId;
			if (isWechat == 1){
				location.href = '/payment-pay/wechat?order_sn='+ i.order_sn + '&client=web&os=h5';
				return;
			}
			i.valiatorOrderSn() && (i.loading.show(), i.submitForm(i.order_sn, payId)
				/*ajaxData('post', '/payment-pay/paySubmit?client=web',  
					      {order_sn: i.order_sn, pay_id: 2}, 
					     function(data){
					    	  location.href='/mobile-user-order/success?order_sn='+i.order_sn;
					    	 
					     }
					)*/
			);
		},
		submitForm:function(sn, payId){
			var o = this;
			// 取得要提交页面的URL  
		    var action = '/payment-pay/paySubmit';  
		    // 创建Form  
		    var form = $('<form></form>');  
		    // 设置属性  
		    form.attr('action', action);  
		    form.attr('method', 'post');  
		    // form的target属性决定form在哪个页面提交  
		    // _self -> 当前页面 _blank -> 新页面  
		    form.attr('target', '_self');  
		    // 创建Input  
		    var pEl = $('<input type="text" name="pay_id" />');  
		    pEl.attr('value', payId);  
		    var snEl = $('<input type="text" name="order_sn" />');  
		    snEl.attr('value', sn);  
		    // 附加到Form  
		    form.append(pEl);  
		    form.append(snEl);  
		    // 提交表单  
		    form.submit();  
		}
},
confirm = {
		options:{
		        isLock:!1,
		        type:1,
		},
		init:function(obj) {
		     var i = this;
		      i.loading = new Loading(),
		      //i.s = obj.s,i.sku_id = obj.sku_id,i.number = obj.number,i.address_id = obj.address_id ? obj.address_id : 0,
		      i.form_data = obj;
		      i.bind();
		},
		bind:function() { 
		        var i = this;
		        i.getConfirmData();
		       
		},
		bindOrderSubmit:function(){
			var i = this;
			 $("#U-btnOrderSubmit").click(function() {
		             i.orderSubmit();
		        });
			 $("#U-selectAddress").click(function(){
				 location.href = "/mobile-user-address/select?df=" + i.form_data;
			 }); 
			 $("#U-orderCoupon").click(function(){
				 location.href = "/mobile-user-order/coupon?orderForm=" + i.form_data + "&payAmount=" + $("#payAmount").html();
			 });
			$("#btn_more_gift").click(function(
			){
				$("#more_gift_details").show();
			});
			$("#btn_close_popwindow").click(function(
			){
				$("#more_gift_details").hide();
			});
		},
		getConfirmData:function(){
			var i = this;
			$.post("/user-order/confirm?client=web", {
				orderForm:i.form_data,
	            client_flag:'web',
	        }, function(t) {
	        	i.loading.hide();
	        	if(0 == t.ret){
	        		i.loadSuccess(t.data);
	        		return;
	        	}
	        	G.pop(t.msg, true);
	        	if(1102 == t.ret){
	        		setTimeout(function() {
	        			location.href = '/quanqiuwa/guanjia.html';
	        		}, 1500);
	        	}
	        	else
	        	{
	        	    setTimeout(function() {
	                    location.href = G.gotoBack();
	                }, 1500);
	        	}
	        	
	        }, "json");
		},
		loadSuccess:function(data){
			var i = this;
			i.renderConfirmData(data);
			i.setFormData(data);
		},
		renderConfirmData: function(data){
			    var i = this;
			    var json = {};
			       json.data = data;
			       renderTemplate.html('U-orderConfirm', 'U-orderConfirmData', json);
			       renderTemplate.html('U-orderTotal', 'U-orderTotalData', json);
			      i.bindOrderSubmit(); 
		},
		setFormData:function(data){
			var i = this;
			i.address_id = data.address.address_id;
			i.orderForm = i.form_data;
		},
		orderSubmit: function(){
			var i = this;
			var json = JSON.parse(i.orderForm);
			json.address_id = i.address_id;
			i.orderForm = JSON.stringify(json);
			$.post("/user-order/create?client=web", {
				orderForm:i.orderForm,
	            client_flag:'web',
	        }, function(t) {
	        	i.loading.hide(), 0 == t.ret ? payment.init(t.data.order_sn) :QqwUtil.msg(t.msg);
	        }, "json");
		}
},coupon = {
		options:{
	        isLock:!1
	},
	payAmount : 0,
	init:function(obj, payAmount) {
	     var i = this;
	     this.payAmount = payAmount;
	      i.loading = new Loading(),
	      i.form_data = obj;
	      i.bind();
	},
	bind:function() { 
	        var i = this;
	        i.getCouponData();
	       
	},
	bindBtn:function(){
		var i = this;
		var listEl = $("#U-couponList").find('.choose');
		$("#J-btnSelectCoupon").click(function(){
			i.submitConfirm();
		});
		if (listEl.length < 1){
			return;
		}
		for(var n=0;n<listEl.length;n++){
			//console.log($(listEl[n]).data('id'));
			$(listEl[n]).click(function(){
				console.log($(this).parent().data('id'));
				var currid = $("#couponId").val();
				var id = $(this).parent().data('id');
				if (id == currid){
					$(this).removeClass('on');
					$("#couponId").val(0);
				}else{ 
					$("#U-couponList").find('.choose').removeClass('on');
					$(this).addClass('on');
					$("#couponId").val(id);
				}
			});
		}
	},
	getCouponData:function(){
		var i = this;
		$.post("/user-order/confirm?client=web", {
			orderForm:i.form_data,
            client_flag:'web',
        }, function(t) {
            i.loading.hide(),  0 == t.ret ?  i.loadSuccess(t.data):QqwUtil.msg(t.msg);
        }, "json");
	},
	loadSuccess:function(data){
		var i = this;
		i.renderCouponData(data);
	},
	renderCouponData: function(data){
		    var i = this;
		    var json = {};
		       json.list = data.couponList;
		       json.id = data.couponId;
		       renderTemplate.html('U-couponList', 'U-couponListData', json);
		      $("#couponId").val(data.couponId);
		       i.bindBtn(); 
		      
	},
	 getSkuData: function(obj){
    	 var skuArr = new Array();
    	  for ( var p in obj ){
    		  //console.log(obj[p]);
    		  skuArr.push(obj[p].sku_id + '_' + obj[p].goods_number);
    	  }
    	  //console.log(skuArr);
    	  return JSON.stringify(skuArr);
     },
	submitConfirm:function(){
	 	var o = this;
		var obj = JSON.parse(o.form_data);
		var coupon_id = $("#couponId").val();
		if (coupon_id)
		{
		    var worth = parseInt($("#coupon" + coupon_id).val()); 
		    if (worth > this.payAmount)
		    {
		        return QqwUtil.msg("订单不满足优惠券使用条件 ，优惠券不可使用");
		    }
		    
		}
		obj.coupon_id = coupon_id;
		// 取得要提交页面的URL  
	    var action = '/mobile-user-order/confirm';  
	    // 创建Form  
	    var form = $('<form></form>');  
	    var data = o.getSkuData(obj.goods);
	   // console.log(data);return;
	    // 设置属性  
	    form.attr('action', action);  
	    form.attr('method', 'post');  
	    // form的target属性决定form在哪个页面提交  
	    // _self -> 当前页面 _blank -> 新页面  
	    form.attr('target', '_self');  
	    // 创建Input  
	    var sEl = $('<input type="text" name="s" />');  
	    sEl.attr('value', obj.s); 
	    var addrEl = $('<input type="text" name="aid" />');  
	    addrEl.attr('value', obj.address_id);  
	    var couponEl = $('<input type="text" name="coupon_id" />');  
	    couponEl.attr('value', obj.coupon_id);  
	    var dataEl = $('<input type="text" name="data" />');  
	    dataEl.attr('value', data);  
	    // 附加到Form  
	    form.append(sEl);  
	    form.append(addrEl);  
	    form.append(couponEl);  
	    form.append(dataEl);  
	    // 提交表单  
	    form.submit();  
	}
		
};
