import './orderDetail.scss';

import { QqwUtil, Loading } from '../../../../js/qqw_ultilities';
import { EventUtil } from '../../../../js/qqw_eventutil';
import QqwApp from '../../../../js/qqw_app';

import template from '../../../../js/template-native-debug';
import tpl_userOrderDetailV2 from '../../../../tpl/user_order_detailv2.tpl';
import { orderApi, doBtnClick } from './order_module';

let tplRender
    , $goodsLeft
    ;

(new QqwApp())
		.init(() => {
			FastClick.attach(document.body);
			bindOrderDetail();
			tplRender = template.compile(tpl_userOrderDetailV2);
		})
		.useStateParam( () => {
			return { order_sn: window.User.Order.$data };
		})
    .initAfterFirstFetch(bindOrderDetailLeft)
		.fetch(orderApi.detailOrder, (data) => {
            Array.from(data.goods_list).map((good, idx) => {
                data.goods_list[idx].goods_attr = '规格: ' + good.goods_attr;
                data.goods_list[idx].goods_number = 'X' + good.goods_number;
            });
			QqwUtil.renderTemplate.append( 'U-orderDetail', tplRender({data: data}) );
		})
		.start();

function bindOrderDetailLeft() {
  $goodsLeft = document.getElementById('shippingGoodsLeft');
  EventUtil.addHandler(document.getElementById('shippingGoodsLeftBtn'), 'click', (event) => {
    event = EventUtil.getEvent(event);
    let target = EventUtil.getTarget(event);
    if (target.nodeName === 'SPAN') {
      target = target.parentElement;
    }
    if (target.nodeName === 'LI') {
      if ($goodsLeft.className) {
        $goodsLeft.className = '';
        target.firstElementChild.innerHTML = '收起';
        target.lastElementChild.className = 'shipping-good-item-collapse-icon-up';
      } else {
        $goodsLeft.className = 'hidden';
        target.firstElementChild.innerHTML = '展开';
        target.lastElementChild.className = 'shipping-good-item-collapse-icon-down';
      }
    }
    return true;
  });
}

function bindOrderDetail() {
	EventUtil.addHandler(document.getElementById('U-orderDetail'), 'click', (event) => {
  	event = EventUtil.getEvent(event);
    let target = EventUtil.getTarget(event);
    console.log(target.nodeName + ', = ' + target.className);
    if (target.nodeName === 'BUTTON') {
      EventUtil.stopPropagation(event);
      EventUtil.preventDefault(event);
      if (target.className === 'shipping-order-operation') {
      	EventUtil.stopPropagation(event);
      	EventUtil.preventDefault(event);
      	doBtnClick(target.dataset.btn, target.dataset.order_sn);
      	return ;
      }
      if (target.className === 'shipping-good-item-price-action') {
      	if (target.dataset.alreadyReplay === '1') {
      		location.href = '/mobile-user-order/service#applydetail?order_sn=' + target.dataset.returnsn;
      	} else {
      		location.href = '/mobile-user-order/service?order_sn=' + target.dataset.ordersn + '&goods_id=' + target.dataset.goodsid + '&product_id=' + target.dataset.productid;
      	}
      	return ;
  		}
    }
  });
}
