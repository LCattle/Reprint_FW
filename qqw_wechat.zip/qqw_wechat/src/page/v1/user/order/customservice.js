import './customservice.scss';

import { QqwUtil, Loading } from '../../../../js/qqw_ultilities';
import { EventUtil } from '../../../../js/qqw_eventutil';
import QqwApp from '../../../../js/qqw_app';

import template from '../../../../js/template-native-debug.js';
import { orderApi } from './order_module';

const tpl_customServiceType =
`
<%for (var i = 0; i < list.length; i++) {%>
<li class="custom-service-item">
  <input class="custom-service-item-choose or_item1" type="radio" name="customServiceChoose" value="<%=list[i].type%>">
  <div class="custom-service-item-content"><p class="custom-service-item-title"><%=list[i].name%></p>
    <span class="custom-service-item-desc"><%=list[i].desc%></span></div>
</li>
<%}%>
`;

const tpl_customServiceReplay =
`
<%for (var i = 0; i < list.length; i++) {%>
<div class="replay-msg-container">
	<aside class="replay-msg-item">
		<span class="replay-msg"><%=list[i].remark%></span>
		<p class="replay-msg-time"><%=list[i].dateline%></p>
	</aside>
</div>
<%}%>
`;

let tplApplyRender
		, tplReplyRender
		, $navTitle
		, $applyChooseArr
		, $sectionApply
		, $sectionApplyOk
		, $sectionApplyDetail
		, returnSn
		;

let locationHash = location.hash;
let searchJson = QqwUtil.getSearchToJson();

let theFetchMethod = 'get';
let theFetchApi = orderApi.customServiceType;
let theFetchCallback = (data) => {
		QqwUtil.renderTemplate.append( 'U-customServiceContainer', tplApplyRender({list: data.list}) );
		if (!$sectionApply.className) {
			$applyChooseArr = QqwUtil.$q('.custom-service-item-choose');
			$applyChooseArr[0].checked = true;
			return ;
		}
		if (!$sectionApplyOk.className) {
			$navTitle.innerHTML = '提交申请';
			return ;
		}
		if (!$sectionApplyDetail.className) {
			$navTitle.innerHTML = '售后详情';
		}
	};

if (locationHash === '#applydetail') {
	theFetchMethod = 'post';
	theFetchApi = orderApi.customServiceDetail;
	theFetchCallback =renderCustomServiceReply;
}

// 主控制器
let customServiceApp = new QqwApp();
customServiceApp.init(() => {
			FastClick.attach(document.body);			// 移动端点击事件 hack
			tplApplyRender = template.compile(tpl_customServiceType);
			tplReplyRender = template.compile(tpl_customServiceReplay);
			bindCustomService();
			pageInit();
			// renderCustomServiceReply();			// only for debug
		})
		.fetch(theFetchApi, theFetchCallback, theFetchMethod);

if (theFetchMethod === 'post') {
	customServiceApp.useStateParam( () => {
		return { return_sn: searchJson.order_sn };
	});
}
customServiceApp.start();

function pageInit() {
	let $qqwNavReturn = document.getElementById('qqwNavReturn');
	$qqwNavReturn.href = $qqwNavReturn.dataset.href + searchJson.order_sn;

	let $orderDetail = document.getElementById('backOrderDetail');
	$orderDetail.href - $orderDetail.dataset.href + searchJson.order_sn;

	$navTitle = document.getElementById('qqwNavTitle');
	$sectionApply = document.getElementById('apply');
	$sectionApplyOk = document.getElementById('applyOk');
	$sectionApplyDetail = document.getElementById('U-applyDetail');
	if (locationHash === '#applydetail') {
		$sectionApply.className = 'hidden';
		$sectionApplyOk.className = 'hidden';
		$sectionApplyDetail.className = '';
	}
}

function bindCustomService() {

	EventUtil.addHandler(document.getElementById('customServiceApply'), 'click', (event) => {
		if (!searchJson.order_sn || !searchJson.goods_id || !searchJson.product_id) {
			return ;
		}
		let remark = document.getElementById('customServiceApplyRemark').value;
		if (remark.length >= 200) {
			QqwUtil.msg('申请说明过长，仅限200字');
			return ;
		}
		let chooseTypeValue = 1;
		for (let idx = 0, size = $applyChooseArr.length; idx < size; ++idx) {
			if ($applyChooseArr[idx].checked) {
				chooseTypeValue = $applyChooseArr[idx].value;
				break ;
			}
		}
		QqwUtil.ajaxData('post', orderApi.customServiceApply,
			{ order_sn: searchJson.order_sn,
				goods_id: searchJson.goods_id,
				product_id: searchJson.product_id,
				type: chooseTypeValue,
				remark: remark
			}, (data) => {
				returnSn = data.return_sn;
				QqwUtil.msg('提交申请成功');
		});
	});

	EventUtil.addHandler(document.getElementById('checkCustomServiceDetail'), 'click', (event) => {
		event = EventUtil.getEvent(event);
    let target = EventUtil.getTarget(event);
		EventUtil.stopPropagation(event);
		EventUtil.preventDefault(event);
		QqwUtil.ajaxData('post', orderApi.customServiceDetail, { return_sn: returnSn }, (data) => {
			renderCustomServiceReply(data);
		});
	});

}

function renderCustomServiceReply(data) {
	$sectionApply.className = 'hidden';
	$sectionApplyOk.className = 'hidden';
	$sectionApplyDetail.className = '';
	let newList = [];
	Array.from(data.list).map((item) => {
		let newItem = {
			dateline: QqwUtil.getSmpFormatDate(new Date(item.dateline*1000), true),
			remark: item.remark
		}
		newList.push(newItem);
	});
	QqwUtil.renderTemplate.append( 'U-applyDetail', tplReplyRender({list: newList}) );
	QqwUtil.renderTemplate.append( 'U-applyDetail', tplReplyRender({list: newList}) );
	QqwUtil.$q('.replay-msg-container')[0].className += ' replay-msg--newest';
	QqwUtil.$q('.replay-msg')[0].className += ' replay-msg--active';
	QqwUtil.$q('.replay-msg-time')[0].className += ' replay-msg--active';
}

