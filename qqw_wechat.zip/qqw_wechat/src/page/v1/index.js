import './homepage/homepage.scss';			// 样式由页面进行统筹，单页应用则需按组件等进行拆分，按优先级加载

import './homepage/homepage.tag';
import { QqwUtil } from '../../js/qqw_ultilities';
import { EventUtil } from '../../js/qqw_eventutil.js';
import QqwApp from '../../js/qqw_app.js';

// import bindSliderMenu from '../../js/qqw_wap_menu.js';
import { BackendApiHomepage } from 'BackendApi';		// 后台api接口文件

import template from '../../js/template-native-debug.js';
import html_menu_slider_list from '../../tpl/html_menu_slider_list.tpl';

let $ = window.Zepto;

// ===========================================================
function bindLikeSign() {
	EventUtil.addHandler(window, 'storage', (e) => {
		let likeSignChangeObj = localStorage.get('thumb_num');
		if (likeSignChangeObj) {
			let likeArr = likeSignChangeObj.splite(';');
			let $likeSigns = QqwUtil.$q('.geek-like');
			for (let idx = 0, size = $likeSigns.length; idx < size; ++idx) {
				if ($likeSigns[idx].firstElementChild.dataset.loveid === likeArr[0]) {
					$likeSigns[idx].lastElementChild.innerHTML = likeArr[1];
					break;
				}
			}
		}
	});
}

/**
 * 绑定页面点击事件，冒泡事件
 * @return {[type]} [description]
 */
function bindMenu() {
	EventUtil.addHandler(document.getElementById('channelMenu'), "click", (e) => {
  	e = EventUtil.getEvent(e);
  	let target = EventUtil.getTarget(e);
  	let className = target.className;

	  if (className.indexOf('hcm-1') !== -1 || className.indexOf('hcm-img-1') !== -1) {
	    Global.sendEvent('event_pinpai1');
	  }
	});
}

// homepage 页面组件 mixin
function qqwOpMixin() {
	this.ajaxData = QqwUtil.ajaxData;
	this.$q = QqwUtil.$q;
	this.each = QqwUtil.each;
}

/**
 * 渲染首屏 banner 块
 * @param  {[type]} banner [banner数据]
 */
function renderHomepageBanner(banner) {
	if (!banner) {
		return;
	}
	let d = document.createDocumentFragment();
	Array.from(banner).map((item) => {
		let bannerLink = document.createElement("a");
		bannerLink.href = item.jump_value || '#';
		bannerLink.className += 'swiper-slide qqw-op-bg';
		bannerLink.style.background = 'transparent url(' + item.ad_img + ') center center / cover no-repeat';
		d.appendChild(bannerLink);
	});
	let $homepageBanner = document.getElementById('homepageBanner');
	$homepageBanner.appendChild(d);
	new window.Swiper ('.qqw-banner-top', {
			autoplay: 4000,
	    loop: true,
	    touchRatio: 1,
  		observer: true,
  		freeMode: false,
	    pagination: '.swiper-pagination'
	});
}

/**
 * 模板 - 数据字典映射
 * @param  {[type]} data [接口json数据]
 */
function getReflectData(data) {
	/*
		banner   					活动banner图
		brand     				品牌
		crowd_funding    	众筹潮品
		purchase_articles	采购达人
		editer_articles  	编辑专栏
		daren_articles   	达人专栏
		column_list    		专栏列表
	 */
	let reflectData = {};
	let urlGoodTogo = '/app-goods/detail?id=';
	let urlArticlTogo = '/app-article/detail?id=';

	// 品牌特供
	let urlBrandTogo = '/app-goods/brand?brand_id=';
	reflectData.brandArr = [];
	Array.from(data.brand || []).map((brItem) => {
		let brandItem = {};
		let nickname = brItem.nickname;
		brandItem.brandid = 'brand' + brItem.id;
		brandItem.speclife = {
			id: brItem.id,
			class: 'brand',			// 图标
			identity: nickname + ' | ' + brItem.position,
			islove: brItem.islove,
			lovenum: brItem.love_num,
			bg: brItem.picurl1,
			url: urlArticlTogo + brItem.id + '&ref=special',
			slogan: brItem.title,
			tip: brItem.content,
		}
		if (nickname.length >= 20) {
			brandItem.speclife.identity = nickname.substring(0, 17) + '... | ' + brItem.position;
		}
		brandItem.brand = [];		// 品牌特供商品
		Array.from(brItem.goods_list || []).map((goodsItem) => {
			let reflectItem = {
				url: urlBrandTogo + goodsItem.brand_id,
				pic: goodsItem.brand_logo,
				showStyle: brItem.style_type || 1,
				name: goodsItem.brand_name,
				price: '￥' + (goodsItem.min_price || '0.00') + ' 起'
			};
			brandItem.brand.push(reflectItem);
		});
		brandItem.brand.push({
			url: urlArticlTogo + brItem.id + '&ref=special',
			showStyle: brItem.style_type || 1,
			more: '查看更多'
		});
		reflectData.brandArr.push(brandItem);
	});

	// 众筹数据映射
	// reflectData.crowdfundingArr = [];
	// Array.from(data.crowd_funding || []).map((cfItem) => {
	// 	let crowdfundingItem = {};
	// 	crowdfundingItem.crowdFundingid = 'crowdFunding' + cfItem.id;
	// 	crowdfundingItem.cfSpeclife = {
	// 		id: cfItem.id,
	// 		class: '',			// 图标
	// 		nickname: cfItem.nickname,
	// 		position: '',
	// 		lovenum: cfItem.love_num,
	// 		bg: cfItem.picurl1,
	// 		url: '/app-crowdfunding',
	// 		slogan: '',
	// 		tip: ''
	// 	}
	// 	crowdfundingItem.crowdfunding = [];
	// 	Array.from(cfItem.goods_list || []).map((goodsItem) => {
	// 		let reflectItem = {
	// 			url: urlGoodTogo + goodsItem.cf_id,
	// 			pic: goodsItem.pic_one,
	// 			name: goodsItem.cf_name,
	// 			percent: goodsItem.percent_text || '0%',
	// 			percentage: goodsItem.percent || '0',
	// 			price: '￥' + goodsItem.cf_money,
	// 			num: goodsItem.cf_num + '人',
	// 			leftday: '剩余 ' + goodsItem.left_day + ' 天'
	// 		};
	// 		crowdfundingItem.crowdfunding.push(reflectItem);
	// 	});
	// 	crowdfundingItem.crowdfunding.push({
	// 		url: '/app-crowdfunding',
	// 		more: '查看更多'
	// 	});
	// 	reflectData.crowdfundingArr.push(crowdfundingItem);
	// });

	let urlDoyenTogo = '/app-doyen/detail?doyen_id=';
	// 采购达人
	reflectData.purchaseId = (data.purchase_articles.length !== 0) ? (data.purchase_articles)[0].cate_id : '1';
	reflectData.purchase = [];
	getReflectDataForPED('purchase', urlDoyenTogo, data.purchase_articles || [], reflectData.purchase);
	// 编辑专栏
	// reflectData.editorId = (data.editer_articles.length !== 0) ? (data.editer_articles)[0].cate_id : '0';
	// reflectData.editor = [];
	// getReflectDataForPED('editor', urlDoyenTogo, data.editer_articles || [], reflectData.editor);
	// 达人专栏
	reflectData.darenId = (data.daren_articles.length !== 0) ? (data.daren_articles)[0].cate_id : '3';
	reflectData.daren = [];
	getReflectDataForPED('daren', urlDoyenTogo, data.daren_articles || [], reflectData.daren);

	// 达人推荐
	reflectData.column = [];
	let itemWidth = (screen.availWidth - 40) / 2;			// hack
	console.log('itemWidth = ' + itemWidth);
	let itemNameSubIdx = 9;			// iphone5
	if (itemWidth > 140 && itemWidth < 168) {
		itemNameSubIdx = 10;			// iphone6
	} else if (itemWidth >= 168 && itemWidth < 188) {
		itemNameSubIdx = 11;			// iphone 6 plus
	}
	let oddIdx = 0;
	Array.from(data.column_list || []).map((item) => {
		if (item.name.length > (itemNameSubIdx + 1)) {
			item.name =  item.name.substring(0, itemNameSubIdx) + '...';
		}
		let reflectItem = {
			odd: false,
			id: item.doyen_id,
			face: item.face,
			pic: item.show_picture,
			url: urlDoyenTogo + item.doyen_id,
			name: item.nickname,
			title: '-  ' + item.name + '  -',
			subtitle: item.slogan,
			tip: item.article_num + '篇文章'
		};
		if (oddIdx % 2 === 0) {
			reflectItem.odd = true;
		}
		++oddIdx;
		reflectData.column.push(reflectItem);
	});

	return reflectData;
}

/**
 * 产品体验官，达人专栏公用数据映射方法
 */
function getReflectDataForPED(idFlag, urlTogo, reflecteData, newReflectedData) {
	let urlGoodTogo = '/app-goods/detail?id=';
	let urlArticlTogo = '/app-article/detail?id=';
	Array.from(reflecteData).map((item) => {
		let nickname = item.nickname;
		let reflectItem = {
			id: idFlag + item.id,
			speclife: {
				id: item.id,
				face: item.face,
				identity: nickname + ' | ' + item.position,
				islove: item.islove,
				lovenum: item.love_num,
				bg: item.picurl1,
				url: urlArticlTogo + item.id + '&ref=doyen',
				slogan: item.title,
				tip: item.content 				// 栏目
			},
			brand: []
		};
		if (nickname.length >= 20) {
			reflectItem.speclife.identity = nickname.substring(0, 17) + '... | ' + item.position;
		}
		Array.from(item.goods_list).map((subItem) => {
			let reflectSubItem = {
				id: subItem.id,
				url: urlGoodTogo + subItem.goods_id,
				pic: subItem.goods_thumb,
				showStyle: item.style_type || 1,
				name: subItem.goods_name,
				price: '￥' + subItem.shop_price
			};
			reflectItem.brand.push(reflectSubItem);
		});
		reflectItem.brand.push({
			url: urlArticlTogo + item.id + '&ref=doyen',
			showStyle: item.style_type || 1,
			more: '查看更多'
		});
		newReflectedData.push(reflectItem);
	});
}

(new QqwApp())
		.domReady(() => {
			FastClick.attach(document.body);			// 移动端点击事件 hack
			riot.mixin('util', qqwOpMixin);
			riot.mixin('event', EventUtil);
		  bindMenu();
		  bindLikeSign();
		 	// bindSliderMenu();
			// QqwUtil.renderTemplate.append('TPL-sliderList', template.compile(html_menu_slider_list)({}));
		})
		.initBeforeFirstFetch((data) => {	// 保证首屏先渲染结构
			renderHomepageBanner(data.banner);
		})
		.fetch(BackendApiHomepage, (data) => {
			let reflectData = getReflectData(data);
			data = null;
			riot.mount('homepage', reflectData);
		})
		.start();

setTimeout(() => {document.getElementById('homepageGeekRecruit').className = 'homepage-geek-aside'; }, 2000);