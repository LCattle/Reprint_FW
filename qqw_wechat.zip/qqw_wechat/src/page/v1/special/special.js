import './special.scss';

import './specialpage.tag';
import { AnimationUtil } from '../../../js/qqw_animation';
import { QqwUtil } from '../../../js/qqw_ultilities';
import { EventUtil } from '../../../js/qqw_eventutil';
import QqwPagestate from '../../../js/qqw_pagestate';
import QqwApp from '../../../js/qqw_app';

import { BackendApiSpecial } from 'BackendApi';		// 后台api接口文件

let reflectData
		, specialInstance
		, qqwPageState
		, specialApp
		;

specialApp = new QqwApp();
qqwPageState = new QqwPagestate();
qqwPageState
		.set('ps', 48)
		.set('each', 8)
		.set('scrollSignDistance', 80)
		.build();			// should be call before app start

function qqwOpMixin() {
	this.$q = QqwUtil.$q;
	this.each = QqwUtil.each;
	this.slideToggle = AnimationUtil.slideToggle;
	this.qqwPageState = qqwPageState;
	this.ajaxData = QqwUtil.ajaxData;
}

// ===========================================================

/**
 * 模板 - 数据字典映射
 * @param  {[type]} data [接口json数据]
 */
function getReflectData(data) {
	let reflectData = {};
	let urlArticlListTogo = '/app-article/detail?id=';

	reflectData.special = [];

	let idx = 0;
	let jMore = 0;
	Array.from(data.list || []).map((articleItem) => {
		let article = {
			class: 'special-article special-article-' + idx,
			banner: {
				bg: articleItem.images,
				face: articleItem.logo,
				title: articleItem.name,
				ads: articleItem.ads,
				subtitle: articleItem.slogan,
				num: '[' + articleItem.article_num + '篇文章]',
				desc: articleItem.intro,
			},
			column: [],
			more: []
		}
		jMore = 0;
		Array.from(articleItem.articleList || []).map((item) => {
			let specialItem = {};
			specialItem.speclife = {
				logo: item.logo,			// 图标
				identity: item.title || '这里是标语',
				bg: item.picurl1,
				url: urlArticlListTogo + item.id,
				title: item.doyen_name,
				desc: item.doyen_name,
				lovenum: item.love_num,
				islove: item.islove,
				// tip: item.article_num + ' 篇文章',
			}
			if (jMore >= 4) {
				article.more.push(specialItem);
			} else {
				article.column.push(specialItem);
			}
			++jMore;
		});
		reflectData.special.push(article);
		++idx;
	});

	return reflectData;
}

// 主控制器
specialApp
		.domReady(() => {
			FastClick.attach(document.body);			// 移动端点击事件 hack
			riot.mixin('util', qqwOpMixin);
			riot.mixin('event', EventUtil);
		})
		.useScrollListener(qqwPageState.getScrollHandler())
		.useStateParam(() => {
			let pageIdx = qqwPageState.get('p') + 1;
			qqwPageState.set('p', pageIdx);
			return '?p=' + (pageIdx) + '&ps=' + qqwPageState.get('ps');
		})
		.initAfterFirstFetch((data) => {
			qqwPageState.updatePageState();				// 更新页面状态，之后页面状态类会自行处理
			specialInstance = riot.mount('specialpage', { special: [] })[0];
			qqwPageState
					.preTrigger(specialApp.doAjaxFetch)
					.updateCallback(specialInstance.update);
			data = null;
		})
		.fetch(BackendApiSpecial, (data) => {
			reflectData = getReflectData(data);
			qqwPageState.set( 'totalItemCount', (qqwPageState.get('totalItemCount') + data.list.length) );
			qqwPageState.addItemToCache(reflectData.special);
			if (reflectData.special.length < qqwPageState.get('ps')) {
				qqwPageState.set('noMoreFlag', false);
				let $more = document.getElementById('pushMore');
				$more.className = 'qqw-push-more-no-content';
				$more.firstElementChild.innerHTML = '— 更多内容 敬请期待 —';
			}
			qqwPageState.setHandling(false);
		})
		.start();
