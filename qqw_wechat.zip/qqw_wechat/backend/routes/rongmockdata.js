var express = require('express'),
	router = express.Router(),
	moment = require('moment');

router.get('/list', function(req, res, next) {
	res.json({"ret":"0","msg":"\u64cd\u4f5c\u6210\u529f","data":{"count":"11","list":[{"id":"11","picurl1":"http:\/\/7xp9qs.com1.z0.glb.clouddn.com\/57c9651983a18.png","title":"\u5f88\u597d\u975e\u5e38\u597d","doyen_name":"","love_num":"0","islove":"0"},{"id":"10","picurl1":"http:\/\/7xp9qs.com1.z0.glb.clouddn.com\/57c7d845359e8.png","title":"gogogo","doyen_name":"","love_num":"0","islove":"0"},{"id":"9","picurl1":"http:\/\/7xp9qs.com1.z0.glb.clouddn.com\/57c7d6712250f.png","title":"\u59b9\u59b9\u4f60\u771f\u597d","doyen_name":"","love_num":"0","islove":"0"},{"id":"8","picurl1":"http:\/\/7xp9qs.com1.z0.glb.clouddn.com\/57c7d6712250f.png","title":"\u59b9\u59b9\u4f60\u771f\u597d","doyen_name":"","love_num":"0","islove":"0"},{"id":"7","picurl1":"http:\/\/7xp9qs.com1.z0.glb.clouddn.com\/57c7d2ece8aa2.png","title":"\u5566\u5566\u5566","doyen_name":"","love_num":"0","islove":"0"},{"id":"6","picurl1":"http:\/\/7xp9qs.com1.z0.glb.clouddn.com\/57c7ccd50f5b9.jpg","title":"test","doyen_name":"","love_num":"0","islove":"0"},{"id":"5","picurl1":"http:\/\/7xp9qs.com1.z0.glb.clouddn.com\/57c7c7ef498ae.jpg","title":"\u6211\u665a\u70b9\u70b9","doyen_name":"","love_num":"0","islove":"0"},{"id":"4","picurl1":"http:\/\/7xp9qs.com1.z0.glb.clouddn.com\/57c792b1b3046.png","title":"\u8fd9\u4e2a\u662f\u6587\u7ae0","doyen_name":"","love_num":"0","islove":"0"},{"id":"3","picurl1":"","title":"\u8fd9\u4e2a\u662f\u4f17\u7b79","doyen_name":"","love_num":"0","islove":"0"},{"id":"2","picurl1":"http:\/\/7xp9qs.com1.z0.glb.clouddn.com\/57c6b048ddcff.png","title":"\u4f60\u662f\u6700\u597d\u7684","doyen_name":"","love_num":"1","islove":"0"}],"pagecount":"2"},"timestamp":1472903958});
});

router.get('/mock/discovery/category', function(req, res, next) {
	res.json({
		ret: "0",
		msg: "操作成功",
		data: {
			list: [{
				cat_id: "629",
				cat_name: "日化用品",
				cat_img: "/img/category_second/discover_img11@2x.png",
				level: 1,
				child:[{
					cat_id: "704",
					cat_name: "家用洗涤",
					cat_img: "http://7xp9qs.com1.z0.glb.clouddn.com/56dd3514981f9.jpg",
					level: 2
				}, {
					cat_id: "636",
					cat_name: "日化护理",
					cat_img: "",
					level: 2
				}]
			}, {
				cat_id: "1002",
				cat_name: "母婴*",
				cat_img: "/img/category_second/discover_img09@2x.png",
				level: 1,
				child: [{
					cat_id: "1202",
					cat_name: "婴儿辅食",
					cat_img: "",
					level: 2
				}, {
					cat_id: "1003",
					cat_name: "奶粉",
					cat_img: "",
					level: 2
				}]
			}]
		}
	});
});

router.get('/mock/discovery/subcategory', function(req, res, next) {
	let items = [
		{
			id: '5',
			image: '/img/category_second/discover_pro_img01@3x.png',
			name: '银锐系列六件套',
			price: '499.90',
			collect_num: 20
		}, {
			id: '15',
			image: '/img/category_second/discover_pro_img02@3x.png',
			name: '克劳斯梅格汤锅炒锅超级无敌长标题套装',
			price: '30.80',
			collect_num: 20
		}, {
			id: '25',
			image: '/img/category_second/discover_pro_img03@3x.png',
			name: '你没看错，只要0.99，不是9块9',
			price: '0.99',
			collect_num: 111222333
		}
	];
	items = items.concat(items);			// 6
	items = items.concat(items);			// 12
	items = items.concat(items);			// 24
	items = items.concat(items);			// 48
	res.json({
		ret: "0",
		msg: "操作成功",
		data: {
			merchant: items
		}
	});
});

module.exports = router;
